﻿using System.ComponentModel.DataAnnotations;

namespace WearHouse_API.Models
{
    public class Users
    {
        [Key]
        [StringLength(20)]
        public Guid UserId { get; set; }

        [MaxLength(255)]
        public string Name { get; set; }

        [MaxLength(255)]
        public string Email { get; set; }

        [MaxLength(255)]
        public string Password { get; set; }
    }
}
