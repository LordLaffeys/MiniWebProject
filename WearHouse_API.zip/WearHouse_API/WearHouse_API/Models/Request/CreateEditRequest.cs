﻿using System.ComponentModel.DataAnnotations;

namespace WearHouse_API.Models.Request
{
    public class CreateEditRequest
    {
        [Required]
        public Guid UserId { get; set; }

        [Required]
        public string OldCategory { get; set; }

        [Required]
        public string NewCategory { get; set; }
    }
}
