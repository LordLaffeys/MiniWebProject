﻿using System.ComponentModel.DataAnnotations;

namespace WearHouse_API.Models.Request
{
    public class CreateLoginRequest
    {
        [Required]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
