﻿using System.ComponentModel.DataAnnotations;

namespace WearHouse_API.Models.Request
{
    public class CreateCategoryRequest
    {
        [Required]
        public Guid UserId { get; set; }

        [Required]
        public string CategoryName { get; set; }
    }
}
