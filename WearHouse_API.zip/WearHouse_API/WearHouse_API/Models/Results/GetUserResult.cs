﻿namespace WearHouse_API.Models.Results
{
    public class GetUserResult
    {
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

    }
}
