﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace WearHouse_API.Models
{
    public class Categories
    {
        
        [StringLength(20)]
        [NotNull]
        [ForeignKey("Users")]
        public Guid UserId { get; set; }

        [Key]
        [NotNull]
        public int CategoryId { get; set; }

        [MaxLength(255)]
        public string CategoryName { get; set; }
    }
}
