﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using WearHouse_API.Data;
using WearHouse_API.Models;
using WearHouse_API.Models.Request;
using WearHouse_API.Models.Results;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WearHouse_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/<UserController>
        [HttpGet]
        [Route("get_users")]
        public List<Users> getUsers()
        {
            var userList = _context.Users
                .Select(x => new Users
                {
                    UserId = x.UserId,
                    Name = x.Name,
                    Email = x.Email,
                    Password = x.Password,
                });

            return userList.ToList();
        }

        [HttpGet]
        [Route("get_categories")]
        public List<Categories> getCategories(string userId)
        {
            try
            {
                var cateogryList = _context.Categories
                .Where(x => x.UserId == new Guid(userId))
                .Select(x => new Categories
                {
                    UserId = x.UserId,
                    CategoryId = x.CategoryId,
                    CategoryName = x.CategoryName,
                })
                .ToList();

                return cateogryList;
            }
            catch (Exception ex)
            {
                return new List<Categories>();
            }
            
        }

        // POST api/<UserController>
        [HttpPost]
        [EnableCors]
        [Route("register")]
        public ActionResult Register([FromBody] CreateUserRequest newUser)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if(_context.Users.Any(x => x.Email == newUser.Email)) 
            { 
                return NotFound("User already Exist");
            }

            var user = new Users
            {
                UserId = newUser.UserId,
                Name = newUser.Name,
                Email = newUser.Email,
                Password = newUser.Password,
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            return Ok(); 
        }

        [HttpPost]
        [EnableCors]
        [Route("login")]
        public GetUserResult PostLogin([FromBody] CreateLoginRequest newUser)
        {
            var UserInfo = new GetUserResult();

            if (!ModelState.IsValid)
            {
                return UserInfo;
            }

            var user = _context.Users.FirstOrDefault(x => x.Email == newUser.Email && x.Password == newUser.Password);

            if (user != null)
            {
                UserInfo.UserId = user.UserId.ToString();
                UserInfo.Name = user.Name;
            }
            else
            {
                return null;
            }

            return UserInfo;
        }

        [HttpPost]
        [EnableCors]
        [Route("add_category")]
        public ActionResult addCategory([FromBody] CreateCategoryRequest newCategory)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (_context.Categories.Any(x => x.CategoryName == newCategory.CategoryName && x.UserId == newCategory.UserId) != false)
            {
                return NotFound("Category already exist");
            }

            var cateogory = new Categories
            {
                UserId = newCategory.UserId,
                CategoryName = newCategory.CategoryName
            };

            _context.Categories.Add(cateogory);
            _context.SaveChanges();

            return Ok();
        }


        [HttpPut]
        [EnableCors]
        [Route("edit_category")]
        public ActionResult EditCategoryPut([FromBody] CreateEditRequest newCategory)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (_context.Categories.Any(x => x.CategoryName == newCategory.OldCategory && x.UserId == newCategory.UserId) == false)
            {
                return NotFound("Category not found!");
            }
            var category = _context.Categories.FirstOrDefault(x => x.CategoryName == newCategory.OldCategory && x.UserId == newCategory.UserId);
            if (category == null)
            {
                return NotFound("Category Not Found!");
            }

            category.CategoryName = newCategory.NewCategory;
            _context.SaveChanges();
            return Ok();
        }


        [HttpDelete]
        [EnableCors]
        [Route("delete_category")]
        public ActionResult deleteCategory([FromBody] CreateCategoryRequest delCateogry)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var updateCategory = _context.Categories.FirstOrDefault(x => x.UserId == delCateogry.UserId && x.CategoryName == delCateogry.CategoryName);

            if (updateCategory == null)
            {
                return NotFound("Category not found");
            }

            _context.Categories.Remove(updateCategory);

            _context.SaveChanges();

            return Ok();
        }

    }
}
