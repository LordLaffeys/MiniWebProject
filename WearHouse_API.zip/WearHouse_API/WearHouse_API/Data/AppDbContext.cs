﻿using Microsoft.EntityFrameworkCore;

using WearHouse_API.Models;

namespace WearHouse_API.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        { }

        public DbSet<Users> Users { get; set; }

        public DbSet<Categories> Categories { get; set; }
    }
}
